package node;
public class Node<T> {
    private T data;       
    private Node<T> next;   
    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    //Getter for self referential data
    public Node<T> getNext() {
        return next;
    }

    //Setter for self referential data
    public void setNext(Node<T> next) {
        this.next = next;
    }

    @Override
    public String toString() {
        return "Node{" +
                "data=" + data +
                '}';
    }
}
